public class Login {
    private String usuario;
    private String password;

}

import java.time.LocalDateTime;
import java.util.List;

public class Turno {
    private Turno turno;
    private List<Paciente> pacientes;
    private Odontologo odontologos;
    private LocalDateTime fechaYHora;



}
